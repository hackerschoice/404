/*
 * Copyright (C) 2007-2010 Stealth.
 * All rights reserved.
 *
 * This is NOT a common BSD license, so read on.
 *
 * Redistribution in source and use in binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. The provided software is FOR EDUCATIONAL PURPOSES ONLY! You must not
 *    use this software or parts of it to commit crime or any illegal
 *    activities. Local law may forbid usage or redistribution of this
 *    software in your country.
 * 2. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 3. Redistribution in binary form is not allowed.
 * 4. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *      This product includes software developed by Stealth.
 * 5. The name Stealth may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/* This program belongs to a set of tools for hotpatching and DSO-handling.
 * The theory and scientific background behind this and other hot-patching
 * tools (injectso) can be found here:
 * http://stealth.openwall.net/papers/heap-cloning.pdf
 * or search the web for "SET-heap-cloning-2009".
 */
#include <assert.h>
#include <stdio.h>
#include <sys/types.h>
#include <stdint.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <elf.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <dlfcn.h>
#include <sys/mman.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/un.h>
#include <sys/syscall.h>
#include <netdb.h>
#include "dlopen-stub.h"


/* also change in dlopen-stub.s, if changed here */
const uint64_t DLOPEN_MAGIC = 0x7350735073507350;
const uint16_t TID_MAGIC = 0x1234;

/* C-way to have a Config:: namespace */
static struct {
	const char *trigger;
	const char *dso;
	const char *symbol;
	pid_t target;
} Config = {
	"none", NULL, "close", 0
};


void die(const char *s)
{
	perror(s);
	exit(errno);
}


/* below are the trigger-functions which might be used to trigger
 * particular code paths inside 'target', so the hooked glibc
 * function is actually called
 */
void trigger_inet(const char *host, const char *port, int type)
{
	int sock;
	struct addrinfo *ai = NULL, hints;

	if ((sock = socket(PF_INET, type, 0)) < 0) {
		printf("[-] Trigger failed: %s\n", strerror(errno));
		return;
	}

	memset(&hints, 0, sizeof(hints));
	hints.ai_family = AF_INET;
	hints.ai_socktype = type;

	if (getaddrinfo(host, port, &hints, &ai) < 0) {
		printf("[-] Trigger failed: %s\n", gai_strerror(errno));
		return;
	}


	if (connect(sock, ai->ai_addr, ai->ai_addrlen) < 0) {
		printf("[-] Trigger failed: %s\n", strerror(errno));
	}
	freeaddrinfo(ai);

	write(sock, "0", 1);
	syscall(SYS_close, sock);
}


void trigger_tcp(const char *trigger)
{
	char host[256], port[16];

	memset(host, 0, sizeof(host));
	memset(port, 0, sizeof(port));
	if (sscanf(trigger, "tcp:%255[^:]:%15[0-9]", host, port) != 2) {
		printf("[-] Wrong trigger format.\n");
		return;
	}

	printf("[+] Using TCP trigger %s:%s\n", host, port);
	trigger_inet(host, port, SOCK_STREAM);
}


void trigger_udp(const char *trigger)
{
	char host[256], port[16];

	memset(host, 0, sizeof(host));
	memset(port, 0, sizeof(port));
	if (sscanf(trigger, "udp:%255[^:]:%15[0-9]", host, port) != 2) {
		printf("[-] Wrong trigger format.\n");
		return;
	}
	printf("[+] Using UDP trigger %s:%s\n", host, port);
	trigger_inet(host, port, SOCK_DGRAM);
}


void trigger_fifo(const char *trigger)
{
	char fifo[256];
	int fd;

	memset(fifo, 0, sizeof(fifo));
	if ((sscanf(trigger, "fifo:%255c", fifo)) != 1) {
		printf("[-] Wrong trigger format.\n");
		return;
	}

	printf("[+] Using FIFO trigger: %s\n", fifo);
	if ((fd = open(fifo, O_RDWR)) < 0) {
		printf("[-] Trigger failed: %s\n", strerror(errno));
		return;
	}
	write(fd, "0", 1);

	/* glibc close() is trapped, remember? even for us ... */
	syscall(SYS_close, fd);
}


void trigger_unix(const char *path, int type)
{
	struct sockaddr_un sun, from;
	int sock = -1;
	socklen_t slen = 0;

	memset(&sun, 0, sizeof(sun));
	memset(&from, 0, sizeof(from));
	sun.sun_family = AF_UNIX;
	from.sun_family = AF_UNIX;
	strncpy(sun.sun_path, path, sizeof(sun.sun_path));
	memcpy(from.sun_path, "\0lasso", 6);

	if (*path == '@')
		sun.sun_path[0] = 0;

	if ((sock = socket(PF_UNIX, type, 0)) < 0) {
		printf("[-] Trigger failed: %s\n", strerror(errno));
		return;
	}
	if (bind(sock, (struct sockaddr *)&from, sizeof(from)) < 0) {
		printf("[-] Trigger failed: %s\n", strerror(errno));
		return;
	}

	for (slen = strlen(path); slen <= sizeof(sun); ++slen) {
		if (connect(sock, (struct sockaddr *)&sun, slen) == 0)
			break;
	}
	if (slen == sizeof(sun) + 1) {
		printf("[-] Trigger failed: %s\n", strerror(errno));
		return;
	}
	write(sock, "0", 1);
	syscall(SYS_close, sock);
}


void trigger_udgram(const char *trigger)
{
	char path[256];
	memset(path, 0, sizeof(path));
	if ((sscanf(trigger, "udgram:%255c", path)) != 1) {
		printf("[-] Wrong trigger format.\n");
		return;
	}
	printf("[+] Using UNIX datagram trigger: %s\n", path);
	trigger_unix(path, SOCK_DGRAM);
}


void trigger_ustream(const char *trigger)
{
	char path[256];
	memset(path, 0, sizeof(path));
	if ((sscanf(trigger, "ustream:%255c", path)) != 1) {
		printf("[-] Wrong trigger format.\n");
		return;
	}
	printf("[+] Using UNIX stream trigger: %s\n", path);
	trigger_unix(path, SOCK_STREAM);
}


void trigger_signal(const char *trigger)
{
	uint16_t sig = 0;

	if (sscanf(trigger, "signal:%hu", &sig) != 1) {
		printf("[-] Wrong trigger format.\n");
		return;
	}
	printf("[+] Using signal trigger: %d\n", sig);
	kill(Config.target, sig);
}


void trigger_none(const char *p)
{
	return;
}


struct triggers {
	const char *match;
	const char *format;
	void (*func)(const char *);
} triggers[] = {
	{"tcp", "tcp:<host>:<port>", trigger_tcp},
	{"udp", "udp:<host>:<port>", trigger_udp},
	{"udgram", "udgram:[@]pathname", trigger_udgram},
	{"ustream", "ustream:[@]pathname", trigger_ustream},
	{"fifo", "fifo:path", trigger_fifo},
	{"signal", "signal:<nr>", trigger_signal},
	{"none", "none", trigger_none},
	{NULL, NULL, NULL}
};


/* Ok, all the triggering is done; now the hard part ... */
char *find_libc_start(pid_t pid)
{
	char path[1024];
	char buf[1026], *start = NULL, *end = NULL, *p = NULL;
	char *addr1 = NULL, *addr2 = NULL;
	FILE *f = NULL;

	snprintf(path, sizeof(path), "/proc/%d/maps", pid);

	if ((f = fopen(path, "r")) == NULL)
		die("[-] fopen");

	for (;;) {
		if (!fgets(buf, sizeof(buf), f))
			break;
		if (!strstr(buf, "r-xp"))
			continue;
		if (!(p = strstr(buf, "/")))
			continue;
		if ((!strstr(p, "/lib64/") && !strstr(p, "/lib/")) || !strstr(p, "/libc-"))
			continue;
		start = strtok(buf, "-");
		addr1 = (char *)strtoul(start, NULL, 16);
		end = strtok(NULL, " ");
		addr2 = (char *)strtoul(end, NULL, 16);
		break;
	}

	fclose(f);
	return addr1;
}


/* Find executable segment offset in file pointed to by fd */
int32_t find_text_64(int fd)
{
	Elf64_Ehdr elf64_ehdr;
	Elf64_Phdr elf64_phdr;
	off_t pos = 0;
	int i = 0, found = 0;

	/* back up original position before start */
	if ((pos = lseek(fd, 0, SEEK_CUR)) < 0)
		die("[-] lseek1");
	if (lseek(fd, 0, SEEK_SET) != 0)
		die("[-] lseek2");

	if (read(fd, &elf64_ehdr, sizeof(elf64_ehdr)) != sizeof(elf64_ehdr))
		die("[-] read1");
	if (lseek(fd, elf64_ehdr.e_phoff, SEEK_SET) != elf64_ehdr.e_phoff)
		die("[-] lseek3");
	for (i = 0; i < elf64_ehdr.e_phnum; ++i) {
		if (read(fd, &elf64_phdr, sizeof(elf64_phdr)) != sizeof(elf64_phdr))
			die("[-] read2");
		if (elf64_phdr.p_type == PT_LOAD && (elf64_phdr.p_flags & PF_X) == PF_X) {
			found = 1;
			break;
		}
	}

	/* restore file position */
	if (lseek(fd, pos, SEEK_SET) != pos)
		die("[-] lseek4");

	if (found)
		return elf64_phdr.p_offset;

	return -1;
}


int32_t change_code(const char *lib, void *my_symbol_addr)
{
	int fd = -1, i = 0;
	int32_t text_off = 0;
	char saved_code[128];
	char *libc_start = find_libc_start(getpid());

	assert(sizeof(saved_code) >= dlopen_stub_bin_len);

	if (!libc_start) {
		fprintf(stderr, "[-] Unable to find my own libc!\n");
		exit(1);
	}

	if ((fd = open(lib, O_RDWR)) < 0)
		die("open");

	if ((text_off = find_text_64(fd)) < 0) {
		fprintf(stderr, "[-] Unable to find .text in %s\n", lib);
		exit(1);
	}


	text_off += (char *)my_symbol_addr - libc_start;
	printf("[+] text offset = %d (0x%x)\n", text_off, text_off);

	if (lseek(fd, text_off, SEEK_SET) != text_off)
		die("[-] lseek");

	if (read(fd, saved_code, sizeof(saved_code)) != sizeof(saved_code))
		die("[-] read");

	if (lseek(fd, text_off, SEEK_SET) != text_off)
		die("[-] lseek");
	if (write(fd, dlopen_stub_bin, dlopen_stub_bin_len) != dlopen_stub_bin_len)
		die("[-] write");
	sync();

	for (i = 0; triggers[i].func; ++i) {
		if (strstr(Config.trigger, triggers[i].match)) {
			printf("[+] Using trigger: %s\n", triggers[i].match);
			triggers[i].func(Config.trigger);
		}
	}

	/* Until I find something better: */
	sleep(1);
	/*read(0, &c, 1);*/

	/* restore code */
	if (lseek(fd, text_off, SEEK_SET) != text_off)
		die("[-] lseek");

	if (write(fd, saved_code, sizeof(saved_code)) != sizeof(saved_code))
		die("[-] write");
	sync();

	/* just in case there could be a race */
	syscall(SYS_close, fd);
	return 0;
}


/* fixup real __libc_dlopen_mode() address and TID in shellcode */
int fix_dlopen_stub(uint64_t addr, uint16_t pid, const char *path)
{
	int i = 0, found = 0;

	assert(strlen(path) <= 16);
	assert(pid != 0);

	for (; i < dlopen_stub_bin_len - 16 && found < 2; ++i) {
		if (*(uint16_t *)&dlopen_stub_bin[i] == TID_MAGIC) {
			*(uint16_t *)&dlopen_stub_bin[i] = pid;
			++found;
			continue;
		}
		if (*(uint64_t *)&dlopen_stub_bin[i] == DLOPEN_MAGIC) {
			*(uint64_t *)&dlopen_stub_bin[i] = addr;
			++found;
		}
	}
	if (found != 2)
		return -1;

	memcpy(&dlopen_stub_bin[dlopen_stub_bin_len - 16], path, strlen(path));
	return 0;
}


void usage()
{
	int i = 0;

	printf("Usage: lasso <-p tid|-1> <-P DSO pathname> [-t trigger] [-S symbol]\n\n"
	       "\t-p tid\t\t -- the targets process TID (equal to PID if single threaded)\n"
	       "\t\t\t    and -1 if you just want to test the DSO stub loader\n"
	       "\t-P DSO pathname\t -- must not be longer than 16 chars\n"
	       "\t-t trigger\t -- trigger to use\n"
	       "\t-S symbol\t -- the symbol used to hook the target; good candidates\n"
	       "\t\t\t    are close or select, depending on the target; 'close' is default\n\n");

	printf("available triggers:\n\n");
	for (i = 0; triggers[i].format; ++i) {
		printf("\t%s\n", triggers[i].format);
	}
	printf("\nPlease backup your /lib64/libc.so (check symlinks!) before hot-patching.\n");

	exit(0);
}


int main(int argc, char **argv)
{
	char *my_libc_dlopen_mode = NULL, *my_libc = NULL, *foreign_libc = NULL,
	     *foreign_libc_dlopen_mode = NULL;
	void *dlh = NULL, *symbol = NULL;
	int c = 0;
	int (*f)() = NULL;

	printf("lasso -- injectso for systems missing ptrace() (C) 2010 by stealth\n\n");

	while ((c = getopt(argc, argv, "p:t:S:P:")) != -1) {
		switch (c) {
		case 'p':
			Config.target = (pid_t)atoi(optarg);
			break;
		case 't':
			Config.trigger = strdup(optarg);
			break;
		case 'P':
			Config.dso = strdup(optarg);
			break;
		case 'S':
			Config.symbol = strdup(optarg);
			break;
		default:
			usage();
		}
	}

	/* test-case to inject into our own process space */
	if (Config.target == -1)
		Config.target = getpid();

	if (!Config.dso || !Config.target)
		usage();

	if (strlen(Config.dso) > 16 || Config.target > 655535) {
		printf("[-] Length of pathname of DSO must not exceed 16 chars and PID not 16bits\n");
		exit(1);
	}

	if ((dlh = dlopen(NULL, RTLD_NOW)) == NULL) {
		fprintf(stderr, "[-] dlopen failure: %s\n", dlerror());
		exit(1);
	}

	if ((my_libc_dlopen_mode = dlsym(dlh, "__libc_dlopen_mode")) == NULL) {
		fprintf(stderr, "[-] Unable to locate my own __libc_dlopen_mode()!\n");
		exit(1);
	}
	printf("[+] my_libc_dlopen_mode = %p\n", my_libc_dlopen_mode);

	if ((my_libc = find_libc_start(getpid())) == NULL) {
		fprintf(stderr, "[-] Unable to locate .text of my own libc mapping!\n");
		exit(1);
	}
	printf("[+] my_libc = %p\n", my_libc);

	if ((foreign_libc = find_libc_start(Config.target)) == NULL) {
		fprintf(stderr, "[-] Unable to locate .text of foreign libc mapping!\n");
		exit(1);
	}
	printf("[+] foreign_libc = %p\n", foreign_libc);


	/* calculate foreigns __libc_dlopen_mode() address */
	foreign_libc_dlopen_mode = foreign_libc + (my_libc_dlopen_mode - my_libc);
	printf("[+] => foreign_libc_dlopen_mode = %p\n", foreign_libc_dlopen_mode);

	if (fix_dlopen_stub((uint64_t)foreign_libc_dlopen_mode, (uint16_t)Config.target, Config.dso) < 0) {
		fprintf(stderr, "[-] Wrong shellcode. Unable to fix dlopen stub loader!\n");
		exit(1);
	}


	/* special testcase to check stub loader */
	if (Config.target == getpid()) {
		f = (int(*)())dlopen_stub_bin;
		mprotect((void *)((uint64_t)f&~(0x1000-1)), 0x2000, PROT_READ|PROT_EXEC|PROT_WRITE);
		f();
		printf("Check /proc/%d/maps\n", Config.target);
		for (;;);
	}

	/* do not allow ^C while doing critical libc updates */
	signal(SIGINT, SIG_IGN);

	symbol = dlsym(dlh, Config.symbol);

	if (symbol == NULL) {
		fprintf(stderr, "[-] Unable to resolv given symbol (%s)\n", dlerror());
		dlclose(dlh);
		exit(1);
	}

	/* hardcoded libc, since we only support x86_64 and libc6 anyways */
	change_code("/lib64/libc.so.6", symbol);
	dlclose(dlh);
	return 0;
}

