/*
 * Copyright (C) 2004,2009 Sebastian Krahmer.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *      This product includes software developed by Sebastian Krahmer.
 * 4. The name Sebastian Krahmer may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/* Plain/crypted forwrad wrapper */

#ifndef __pcwrap_h__
#define __pcwrap_h__

#include <sys/types.h>
#include <string.h>
#include <string>
#include <termios.h>
#include <unistd.h>
#include "rc4.h"



class pc_wrap {
private:

	int r_fd, w_fd;
	bool seen_starttls;
	std::string err;
	const char *starttls_seq;
	FILE *r_stream, *w_stream;
	rc4_key rc4_read_key, rc4_write_key;
	bool server_mode;
	unsigned char *rc4_k1, *rc4_k2;
	struct termios old_client_tattr;
	struct winsize ws;
	bool wsize_signalled;
public:
	pc_wrap(int, int);

	int init(unsigned char *, unsigned char *, bool);

	void reset();

	~pc_wrap();

	int read(void *, size_t);

	int write(const void *buf, size_t blen);

	int write_wsize();

	int check_wsize(int);

	int r_fileno();

	int w_fileno();

	const char *why();

	void enable_crypto() { seen_starttls = 1; }
};


#endif
	
