/*
 * Copyright (C) 2004,2009 Sebastian Krahmer.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *      This product includes software developed by Sebastian Krahmer.
 * 4. The name Sebastian Krahmer may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#include <sys/types.h>
#include <stdio.h>
#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>
#include <signal.h>
#include <termios.h>
#include <sys/ioctl.h>


#include "pty.h"
#include "pcwrap.h"
#include "misc.h"
#include "rc4.h"


struct termios global_tcattr, exit_tattr;

void sig_chld(int)
{
	tcsetattr(0, TCSANOW, &exit_tattr);
	printf("psc: exiting\n");
	exit(0);
}


bool winsize_changed = 0;

void sig_win(int)
{
	winsize_changed = 1;
}


int main(int argc, char **argv)
{
#ifdef HAVE_UNIX98
	pty98 pt;
#else
	pty pt;
#endif
	fd_set rset;
	pid_t pid;
	int r;
	char wbuf[BLOCK_SIZE], rbuf[2*BLOCK_SIZE];
	struct termios tattr;
	unsigned char *rkey = (unsigned char*)PSC_READ_KEY;
	unsigned char *wkey = (unsigned char*)PSC_WRITE_KEY;

	struct sigaction sa;
	memset(&sa, 0, sizeof(sa));
	sa.sa_handler = sig_chld;
	sa.sa_flags = SA_RESTART;

	if (sigaction(SIGCHLD, &sa, NULL) < 0)
		die("psc: sigaction");

	memset(&sa, 0, sizeof(sa));
	sa.sa_handler = sig_win;
	sa.sa_flags = SA_RESTART;
	if (sigaction(SIGWINCH, &sa, NULL) < 0)
		die("psc: sigaction");

	if (pt.open() < 0)
		die(pt.why());
	fix_size(pt.slave());

	if (tcgetattr(0, &tattr) < 0) {
		die("psc: tcgetattr");
	}

	exit_tattr = tattr;

	cfmakeraw(&tattr);
	tattr.c_cc[VMIN] = 1;
	tattr.c_cc[VTIME] = 0;
	//tattr.c_lflag &= ~ECHO;

	global_tcattr = tattr;
	if (tcsetattr(0, TCSANOW, &tattr) < 0)
		die("psc: tcsetattr");

	if ((pid = fork()) == 0) {
		char *a[] = {getenv("SHELL"), NULL};
		extern char **environ;

		if (!*a) {
			die("psc: no shell set via $SHELL");
		}

		close(0); close(1); close(2);
		dup2(pt.slave(), 0); dup2(pt.slave(), 1);
		dup2(pt.slave(), 2);
		setsid();
		ioctl(0, TIOCSCTTY, 0);
		pt.close();
		execve(*a, a, environ);
		die("psc: execve");
	} else if (pid < 0)
		die("psc: fork");

	pc_wrap psc(pt.master(), pt.master());
	psc.init(rkey, wkey, 0);
	close(pt.slave());

	for (;;) {
		FD_ZERO(&rset);
		FD_SET(pt.master(), &rset);
		FD_SET(0, &rset);

		memset(wbuf, 0, sizeof(wbuf));
		memset(rbuf, 0, sizeof(rbuf));
		if (select(pt.master() + 1, &rset, NULL, NULL, NULL) < 0) {
			if (errno == EINTR) {
				if (winsize_changed) {
					psc.write_wsize();
					winsize_changed = 0;
				}
				continue;
			} else {
				die("psc: select");
			}
		}

		if (FD_ISSET(0, &rset)) {
			if ((r = read(0, wbuf, sizeof(wbuf))) <= 0) {
				die("psc: read");
			}
			if (psc.write(wbuf, r) <= 0) {
				die(psc.why());
			}
		} else if (FD_ISSET(pt.master(), &rset)) {
			if ((r = psc.read(rbuf, sizeof(rbuf))) < 0) {
				die(psc.why());
			}
			// STARTTLS/end-sequence seen
			if (r == 0)
				continue;
			if (write(1, rbuf, r) <= 0) {
				die("psc: write");
			}
		}
	}
	
	return 0;
}

