/*
 * Copyright (C) 2004-2010 Sebastian Krahmer.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *      This product includes software developed by Sebastian Krahmer.
 * 4. The name Sebastian Krahmer may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#include <sys/types.h>
#include <stdio.h>
#include <sys/time.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>
#include <termios.h>
#include <sys/ioctl.h>
#include <signal.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "pty.h"
#include "misc.h"
#include "pcwrap.h"

struct termios exit_tattr;

// child == bash exited, send end-sequence
// so psc-local can reset its rc4 state
void sig_chld(int)
{
	tcsetattr(fileno(stdin), TCSANOW, &exit_tattr);
	write(fileno(stdout), "*\n", 2);
	exit(0);
}


int main(int argc, char **argv)
{
#ifdef HAVE_UNIX98
	pty98 pt;
#else
	pty pt;
#endif
	fd_set rset;
	pid_t pid;
	int r;
	char wbuf[BLOCK_SIZE], rbuf[2*BLOCK_SIZE];
	struct termios tattr;
	const char *starttls = STARTTLS;
	unsigned char *rkey = (unsigned char*)PSC_WRITE_KEY;
	unsigned char *wkey = (unsigned char*)PSC_READ_KEY;

	setbuffer(stdin, NULL, 0);
	setbuffer(stdout, NULL, 0);
	setbuffer(stderr, NULL, 0);

	if (pt.open() < 0)
		die(pt.why());

	fix_size(pt.slave());

	if (tcgetattr(fileno(stdin), &tattr) < 0) {
		die("tcgetattr");
	}
	exit_tattr = tattr;

	//tattr.c_lflag &= ~ECHO;
	cfmakeraw(&tattr);

	/* May fails when we are on a portshell */
	tcsetattr(fileno(stdin), TCSANOW, &tattr);

	struct sigaction sa;
	memset(&sa, 0, sizeof(sa));
	sa.sa_handler = sig_chld;
	sa.sa_flags = SA_RESTART;

	if (sigaction(SIGCHLD, &sa, NULL) < 0)
		die("sigaction");

	if ((pid = fork()) == 0) {
		char *a[] = {getenv("SHELL"), NULL};
		extern char **environ;

		if (!*a) {
			die("No shell set via $SHELL");
		}

		dup2(pt.slave(), 0); dup2(pt.slave(), 1);
		dup2(pt.slave(), 2);
		setsid();
		ioctl(0, TIOCSCTTY, 0);
		pt.close();

		execve(*a, a, environ);
		die("execve");
	} else if (pid < 0)
		die("fork");

	close(pt.slave());

	printf("%s", starttls);

	pc_wrap psc(0, 1);
	psc.init(rkey, wkey, 1);
	psc.enable_crypto();

	for (;;) {
		FD_ZERO(&rset);
		FD_SET(pt.master(), &rset);
		FD_SET(0, &rset);
		memset(rbuf, 0, sizeof(rbuf));
		memset(wbuf, 0, sizeof(wbuf));

		if (select(pt.master() + 1, &rset, NULL, NULL, NULL) < 0) {
			if (errno == EINTR)
				continue;
			else {
				break;
			}
		}
		if (FD_ISSET(0, &rset)) {
			if ((r = psc.read(rbuf, sizeof(rbuf))) < 0)
				break;
			// STARTTLS/command seen
			if (r == 0) {
				psc.check_wsize(pt.master());
				continue;
			}
			if (write(pt.master(), rbuf, r) <= 0) {
				break;
			}
		} else if (FD_ISSET(pt.master(), &rset)) {
			if ((r = read(pt.master(), wbuf, sizeof(wbuf))) <= 0) {
				break;
			}
			if (psc.write(wbuf, r) <= 0)
				break;
		}
	}

	tcsetattr(fileno(stdin), TCSANOW, &exit_tattr);
	write(fileno(stdout), "*\n", 2);
	return 0;
}

