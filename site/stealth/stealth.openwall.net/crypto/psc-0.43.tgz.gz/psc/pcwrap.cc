/*
 * Copyright (C) 2004-2010 Sebastian Krahmer.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *      This product includes software developed by Sebastian Krahmer.
 * 4. The name Sebastian Krahmer may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */
#include <sys/types.h>
#include <cstdio>
#include <string.h>
#include <string>
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>
#include <termios.h>
#include <assert.h>
#include <sys/ioctl.h>

#include "pcwrap.h"
#include "misc.h"
#include "rc4.h"


using namespace std;


pc_wrap::pc_wrap(int rfd, int wfd)
	: r_fd(rfd), w_fd(wfd), seen_starttls(0),
	  starttls_seq(STARTTLS), r_stream(NULL), w_stream(NULL),
	  server_mode(0), rc4_k1(NULL), rc4_k2(NULL), wsize_signalled(0)
{
	if ((r_stream = fdopen(r_fd, "r")) == NULL)
		die("pc_wrap::pc_wrap::fdopen(r)");
	if ((w_stream = fdopen(w_fd, "w")) == NULL)
		die("pc_wrap::pc_wrap::fdopen(w)");
	setbuffer(r_stream, NULL, 0);
	setbuffer(w_stream, NULL, 0);
}


int pc_wrap::init(unsigned char *k1, unsigned char *k2, bool s)
{
	tcgetattr(r_fd, &old_client_tattr);

	rc4_k1 = (unsigned char*)strdup((char*)k1);
	rc4_k2 = (unsigned char*)strdup((char*)k2);

	prepare_key(rc4_k1, strlen((char*)rc4_k1), &rc4_read_key);
	prepare_key(rc4_k2, strlen((char*)rc4_k2), &rc4_write_key);

	server_mode = s;

	return 0;
}


void pc_wrap::reset()
{
	seen_starttls = 0;

	// rc4 state machine reset
	prepare_key(rc4_k1, strlen((char*)rc4_k1), &rc4_read_key);
	prepare_key(rc4_k2, strlen((char*)rc4_k2), &rc4_write_key);
}


pc_wrap::~pc_wrap()
{
	fclose(r_stream);
	fclose(w_stream);
	free(rc4_k1);
	free(rc4_k2);
}


int pc_wrap::check_wsize(int fd)
{
	if (!wsize_signalled)
		return 0;
	wsize_signalled = 0;
	int r = ioctl(fd, TIOCSWINSZ, &ws);
	if (r == 0)
		return 1;
	return r;
}


int pc_wrap::read(void *buf, size_t blen)
{
	int r;
	char b64_crypt_buf[2*BLOCK_SIZE];
	char *s = NULL;

	assert(blen >= 3*sizeof(b64_crypt_buf)/4);
	memset(b64_crypt_buf, 0, sizeof(b64_crypt_buf));

	if (seen_starttls) {
		fgets(b64_crypt_buf, sizeof(b64_crypt_buf), r_stream);
		if (!server_mode) {
			// psc-remote is quitting, reset rc4 state
			if (b64_crypt_buf[0] == '*') {
				this->reset();
				printf("psc: Seen end-sequence, disabling crypto!\r\n");
				return 0;
			}
		}
		if ((s = strchr(b64_crypt_buf, '\n')) == NULL) {
			err = "pc_wrap::read::No newline in b64 rstream!";
			return -1;
		}

		*s = 0;
		char *tbuf = new char[sizeof(b64_crypt_buf)];
		r = b64_decode(b64_crypt_buf, (unsigned char*)tbuf);
		rc4((unsigned char*)tbuf, r, &rc4_read_key);
		// normal data?
		if (strncmp(tbuf, "D:channel0:", 11) == 0) {
			memcpy(buf, tbuf + 11, r - 11);
			delete [] tbuf;
			return r - 11;
		// some command
		} else if (strncmp(tbuf, "C:window-size:", 14) == 0) {
			wsize_signalled = 1;
			if (sscanf(tbuf+14, "%hu:%hu:%hu:%hu", &ws.ws_row, &ws.ws_col,
			           &ws.ws_xpixel, &ws.ws_ypixel) != 4)
				wsize_signalled = 0;
			delete [] tbuf;
			return 0;
		}
		delete [] tbuf;
		return 0;
	}

	r = ::read(r_fd, buf, blen);
	if (r <= 0) {
		err = "pc_wrap::read::";
		err += strerror(errno);	
		return -1;
	}

	if (strncmp((char*)buf, starttls_seq, strlen(starttls_seq)) == 0) {
		printf("psc: Seen STARTTLS sequence, enabling crypto.\r\n");
		seen_starttls = 1;
		if (!server_mode) {
			// Disable local echo now, since remote site is
			// opening another PTY with echo
			struct termios tattr;
			if (tcgetattr(r_fd, &tattr) == 0) {
				old_client_tattr = tattr;
				cfmakeraw(&tattr);
				tattr.c_cc[VMIN] = 1;
				tattr.c_cc[VTIME] = 0;
				tcsetattr(r_fd, TCSANOW, &tattr);
			}
			write_wsize();
		}
		return 0;
	}
	return r;
}


int pc_wrap::write(const void *buf, size_t blen)
{
	int r = 0;
	assert(blen <= BLOCK_SIZE);
	char *crypt_buf = NULL;
	unsigned char *b64_crypt_buf = NULL;

	if (seen_starttls) {
		crypt_buf = new char[blen + 32];
		if (!crypt_buf)
			return -1;
		b64_crypt_buf = new unsigned char[2*blen + 64];
		if (!b64_crypt_buf)
			return -1;
		memset(b64_crypt_buf, 0, sizeof(b64_crypt_buf));
		snprintf(crypt_buf, 32, "D:channel0:");
		memcpy(crypt_buf + 11, buf, blen);
		blen += 11;
		rc4((unsigned char*)crypt_buf, blen, &rc4_write_key);
		b64_encode(crypt_buf, blen, b64_crypt_buf);
		fprintf(w_stream, "%s\n", b64_crypt_buf);

		delete [] crypt_buf;
		delete [] b64_crypt_buf;
		return blen - 11;
	}
	r = ::write(w_fd, buf, blen);
	return r;
}


int pc_wrap::write_wsize()
{
	if (!seen_starttls)
		return 0;

	char wsbuf[64];
	unsigned char sbuf[256];
	if (ioctl(0, TIOCGWINSZ, &ws) < 0)
		return -1;
	memset(wsbuf, 0, sizeof(wsbuf));
	snprintf(wsbuf, sizeof(wsbuf), "C:window-size:%hu:%hu:%hu:%hu", ws.ws_row,
	         ws.ws_col, ws.ws_xpixel, ws.ws_ypixel);
	size_t blen = strlen(wsbuf);
	memset(sbuf, 0, sizeof(sbuf));
	rc4((unsigned char*)wsbuf, blen, &rc4_write_key);
	b64_encode(wsbuf, blen, sbuf);
	fprintf(w_stream, "%s\n", sbuf);
	return 0;
}


int pc_wrap::r_fileno()
{
	return r_fd;
}


int pc_wrap::w_fileno()
{
	return w_fd;
}


const char *pc_wrap::why()
{
	return err.c_str();
}

