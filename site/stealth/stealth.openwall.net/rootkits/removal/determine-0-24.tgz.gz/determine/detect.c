/*
 * Copyright (C) 2004 Stealth.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *      This product includes software developed by Stealth.
 * 4. The name Stealth may not be used to endorse or promote
 *    products derived from this software without specific prior written
 *    permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */
#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <dirent.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/mman.h>
#include "detect.h"

#define PID_MAX 0x8000


/* String is XORed with first character
 */
char *xor(char *string)
{
	int i, l = strlen(string);
	for (i = 1; i < l; ++i)
		string[i] ^= string[0];
	return string;
}


int find_hidden_procs()
{
	int i, r = 0;
	struct dirent *de = NULL;
	DIR *dh = NULL;
	char procs[PID_MAX+1];
	
	memset(procs, 0, sizeof(procs));
	if ((dh = opendir("/proc")) == NULL) {
		perror("Cant open /proc! Skipping check.\n");
		return 0;
	}

	while ((de = readdir(dh)) != NULL) {
		if (atoi(de->d_name) > 0 && atoi(de->d_name) <= PID_MAX)
			procs[atoi(de->d_name)] = 1;
	}
	closedir(dh);

	for (i = 1; i <= PID_MAX; ++i) {
		if (kill(i, SIGCONT) == 0) {
			char path[128];
			struct stat st;
			snprintf(path, sizeof(path), "/proc/%d", i);

			/* If the PID is available, but either was not listed by a /proc getdents()
			 * or is not accessible in /proc there must be something wrong.
			 */
			if (stat(path, &st) < 0 || procs[i] == 0) {
				printf("Process with PID %d does not have a appropriate /proc entry. Hidden?\n", i);
				r = 1;
			}
		}
	}
	return r;
}


struct signatures *rk_signatures = NULL;
size_t n_rksignatures = 0;

int scan_kmem(const char *path)
{
	char *strings = NULL;
	char tmp[128] = "/tmp/kmem-stringsXXXXXX";
	char cmd[1024];
	int r = 0, fd = 0, i = 0;
	struct stat st;

	if (close(mkstemp(tmp)) < 0) {
		perror("Cant create temporary file. Skipping check.");
		return 0;
	}

	snprintf(cmd, sizeof(cmd), "dd if=/dev/mem 2>/dev/null|strings > %s", tmp);
	system(cmd);

	if (load_signatures(path) <= 0)
		return 0;

	if ((fd = open(tmp, O_RDONLY)) < 0) {
		perror("Cant find the 'string utillity'. Skipping check.\n");
		return 0;
	}
	fstat(fd, &st);
	if ((strings = (char*)mmap(NULL, st.st_size, PROT_READ, MAP_PRIVATE, fd, 0)) == NULL) {
		perror("Cant map stringified /dev/mem to memory. Skipping check.\n");
		return 0;
	}
	for (i = 0; i < n_rksignatures; ++i) {
		if (strstr(strings, xor(rk_signatures[i].sig)+1) != NULL) {
			printf("Signature of '%s' detected!\n", rk_signatures[i].comment);
			r = 1;
		}
		memset(rk_signatures[i].sig, 0, strlen(rk_signatures[i].sig));
		free(rk_signatures[i].sig);
		free(rk_signatures[i].comment);
	}

	munmap(strings, st.st_size);
	close(fd);
	unlink(tmp);
	return r;
}


int load_signatures(const char *path)
{
	char buf[1024];
	int nsigs = 0;

	FILE *f = fopen(path, "r");
	if (!f) {
		perror("Cant open signature-file.");
		return -1;
	}

	while (fgets(buf, sizeof(buf), f)) {
		memset(buf, 0, sizeof(buf));
		++nsigs;
	}
	if (nsigs % 2) {
		fprintf(stderr, "Wrong format of signature file. Skipping check.\n");
		return -1;
	}
	rewind(f);

	rk_signatures = (struct signatures*)malloc(nsigs * sizeof(struct signatures));
	nsigs = 0;

	while (fgets(buf, sizeof(buf), f)) {
		strtok(buf, "\n");
		rk_signatures[nsigs].sig = strdup(buf);
		memset(buf, 0, sizeof(buf));
		fgets(buf, sizeof(buf), f);
		strtok(buf, "\n");
		rk_signatures[nsigs].comment = strdup(buf);
		++nsigs;
	}
	n_rksignatures = nsigs;
	fclose(f);
	return n_rksignatures;
}

