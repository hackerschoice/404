#ifndef __detect_h__
#define __detect_h__

extern int find_hidden_procs();
extern int load_signatures(const char *);
extern int scan_kmem();

struct signatures {
	char *sig, *comment;
};

#endif

