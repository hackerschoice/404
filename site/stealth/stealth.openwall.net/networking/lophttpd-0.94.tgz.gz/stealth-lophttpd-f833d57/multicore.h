#ifndef __multicore_h__
#define __multicore_h__

namespace misc {

extern int my_core;

int init_multicore();

int setup_multicore(int);

}

#endif

